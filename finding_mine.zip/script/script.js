$(document).ready(function(){
    
    function rand(min,max){
        var result = Math.floor(Math.random()*(max + 1 - min) + min);
        return result;
    }
    
    
    
    $("#btn").click(function(){
        var rownum = $("#rownum").val();
        rownum = parseInt(rownum);
        $("#wrap").empty();
        for(i=0; i<rownum; i++){
            $("#wrap").append("<div class='row'></div>");
            for(j=0; j<rownum; j++){
                $(".row").eq(i).append("<button class='cell'></button>");
            }
        }
        
        var total = rownum * rownum;
        var t = total * 0.2;
        t = parseInt(t);
        for(i=0; i<t; i++){
            $(".cell").eq(rand(0, total)).text("*");
        }
        
        for(i=0; i<total; i++){
            var final = 0;
            if(i<rownum){
//                윗칸이 없음
                if(i%rownum == 0){
//                    왼쪽칸이 없음
                    if($(".cell").eq(i+1).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i+rownum).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i+rownum+1).text() == "*"){
                        final++;
                    }
                }else if(i%rownum == rownum-1){
//                    오른쪽칸이 없음
                    if($(".cell").eq(i-1).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i+rownum).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i+rownum-1).text() == "*"){
                        final++;
                    }
                }else{
//                    왼쪽,오른쪽 다 있음
                    if($(".cell").eq(i-1).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i+1).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i+rownum).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i+rownum-1).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i+rownum+1).text() == "*"){
                        final++;
                    }
                }
            }else if(i >= total-rownum){
//                아랫칸이 없음
                if(i%rownum == 0){
//                    왼쪽칸이 없음
                    if($(".cell").eq(i-rownum).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i+1).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i-(rownum-1)).text() == "*"){
                        final++;
                    }
                }else if(i%rownum == rownum-1){
//                    오른쪽칸이 없음
                    if($(".cell").eq(i-rownum).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i-1).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i-(rownum+1)).text() == "*"){
                        final++;
                    }
                }else {
//                    왼쪽,오른쪽 다 있음
                    if($(".cell").eq(i-1).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i+1).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i-rownum).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i-(rownum+1)).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i-(rownum-1)).text() == "*"){
                        final++;
                    }
                }
            }else{
//                윗칸,아랫칸 다 있음
                if(i%rownum == 0){
//                    왼쪽칸이 없음
                    if($(".cell").eq(i+1).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i-rownum).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i+rownum+1).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i-(rownum-1)).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i+(rownum+1)).text() == "*"){
                        final++;
                    }
                }else if(i%rownum == 4){
//                    오른쪽칸이 없음
                    if($(".cell").eq(i-1).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i-rownum).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i+rownum).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i-(rownum+1)).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i+(rownum-1)).text() == "*"){
                        final++;
                    }
                }else {
//                    왼쪽,오른쪽 다 있음
                    if($(".cell").eq(i-rownum).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i+rownum).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i-1).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i+1).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i-(rownum+1)).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i-(rownum-1)).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i+rownum-1).text() == "*"){
                        final++;
                    }
                    if($(".cell").eq(i+rownum+1).text() == "*"){
                        final++;
                    }
                }
            }
            
            
            if($(".cell").eq(i).text()!="*" && final!=0){
                $(".cell").eq(i).text(final);
            };
        }
        
        $(".cell").click(function(){
            var t = $(this).text();
            if(t == "*"){
                alert("Game over");
                location.reload();
            }else{
                $(this).css({
                    color: "black",
                    backgroundColor: "darkgray",
                    border: "none"
                });
            }
        });
        
    });
    
});





